from django.shortcuts import render, get_object_or_404
from main.models import Mines
# Create your views here.

def main(request):
    #mine = get_object_or_404(Mines, pk=mine_set_Id)
    return render(request, "mine_main.html")

def create(request):
    #mine = get_object_or_404(Mines, pk=mine_set_Id)
    return render(request, "mine_create.html")