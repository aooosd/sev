from django.db import models

# Create your models here.
class Mines(models.Model):
    #mine_loc = [[models.BooleanField()]]
    field_width = models.IntegerField()
    field_height = models.IntegerField()
    