from django.contrib import admin
from main.models import Mines
# Register your models here.
admin.site.register(Mines)